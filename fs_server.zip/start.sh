#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=server.log
cd /fs/
nohup java -Xmx512M -XX:MaxGCPauseMillis=1 -jar fs12.jar > $logname 2>&1  &
echo FinalSpeed start,log file: /fs/$logname