#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=server.log
cd /fs/
nohup java -Xmx128M -XX:MaxGCPauseMillis=10 -jar fs12.jar > $logname 2>&1  &
echo FinalSpeed start,log file: /fs/$logname